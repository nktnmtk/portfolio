
jQuery(function ($) {

  var topBtn = $('.page-top');
  topBtn.hide();


  $(window).scroll(function () {
    if ($(this).scrollTop() > 70) {
      topBtn.fadeIn();
    } else {
      topBtn.fadeOut();
    }
  });

  topBtn.click(function () {
    $('body,html').animate({
      scrollTop: 0
    }, 300, 'swing');
    return false;
  });

  $(window).on('scroll', function () {
    if ($('.slider1').height() < $(this).scrollTop()) {
      $('.header').css('background', 'rgba(17,17,17,1)');
    } else {
      $('.header').css('background', 'rgba(17,17,17,0.5)');
    }
  });

  $(function(){
    $('.js-hamburger').on('click', function(){
      $('.js-hamburger').toggleClass('is-open');
      $('.js-drawer-menu').toggleClass('is-open');
      $('a[href^="#"]').on('click', function() {
        $('.js-hamburger').click(); 
      });
    });
  }());

  $(document).on('click', 'a[href*="#"]', function () {
    let time = 400;
    let header = $('header').innerHeight();
    let target = $(this.hash);
    if (!target.length) return;
    let targetY = target.offset().top - header;
    $('html,body').animate({ scrollTop: targetY }, time, 'swing');
    return false;
  });



});

var stroke;
stroke = new Vivus('mask', {
    start:'manual',
    type: 'scenario-sync',
    duration: 10,
    forceRender: false,
    animTimingFunction:Vivus.EASE,
},
function(){
         $("#mask").attr("class", "done");
}
);

$(window).on('load',function(){
    $("#splash").delay(2000).fadeOut('slow');
  $("#splash_logo").delay(2000).fadeOut('slow');
        stroke.play();
});

AOS.init();